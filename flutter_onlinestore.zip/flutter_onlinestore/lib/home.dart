import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class home extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return state();
  }

}

class state extends State<home>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        backgroundColor: Colors.blueGrey[50],
        appBar:AppBar(
          title: Text('KITCHEN COLLECTION'),
        ) ,
        body: grid() );
  }

  Widget grid(){
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemBuilder: (_, index) => new Padding(padding: EdgeInsets.all(15),
        child: Container(
            height: 400,
            decoration: new BoxDecoration(
                color: Colors.white,
                borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(15.0),
                  topRight: const Radius.circular(15.0),
                  bottomRight:  const Radius.circular(15.0),
                  bottomLeft:  const Radius.circular(15.0),
                )
            ),
            child: new Center(
              child: Column(
                children: [
                  Padding(padding: EdgeInsets.only(top: 5),
                    child:  Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(
                              'assets/assets/spacro.jpg'),
                          fit: BoxFit.fill,
                        ),
                        shape: BoxShape.circle,
                      ),

                    ),),
                  Padding(padding: EdgeInsets.only(top: 8),
                    child: Text('SPACRO NEW MODEL DISH'),) ,
                  Padding(padding: EdgeInsets.only(top: 2),
                    child: Text('2780/-',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),),
                  Padding(padding: EdgeInsets.only(top: 2),
                    child: Text('5% Discount',style: TextStyle(color: Colors.green),),)
                ],
              ),
            )
        ),),
      itemCount: 10,
    );
  }
}